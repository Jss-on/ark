# Installation
Run this command
`sudo apt install ./system-watchdog-monitor_1.0-1.deb`

